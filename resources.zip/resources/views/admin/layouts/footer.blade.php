<div class="footer-left">
    All rights reserved &copy; {{ date('Y') }}
</div>
